﻿namespace RaceData
{
    public class RaceCourse
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int TotalDistance { get; set; }      // Total length of course in meters
    }
}
