﻿using System;

namespace RaceData
{
    public class RaceEvent
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public DateTime StartDateTime { get; set; }
    }
}
